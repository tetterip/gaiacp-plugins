# Changelog

Every version of this plugin, newest first. The version is in `plugin.json`; it is installed from the plugin catalogue.

## [1.0.6] - 2026-11-22

- Moved out of GaiaCP into the plugin catalogue: install it under Settings → System → Plugin catalogue. An install that
  had it keeps it, with its settings and data, and updates it from the catalogue from now on. No change to how it
  works.

## [1.0.5] - 2026-11-07

- /owed says "1 payment notice" or "3 payment notices" in every language, instead of "notice(s)"

## [1.0.4] - 2026-11-06

- /today counts the orders and tickets of today in your timezone, and /owed reads due dates as days, now that GaiaCP stores times in UTC

## [1.0.3] - 2026-10-26

- Translated into German, Spanish, French, Italian, Dutch, Polish, Brazilian Portuguese and Turkish (machine translated)

## [1.0.2] - 2026-10-24

- Its settings page is under Settings → Email & notifications (Settings regrouped)

## [1.0.1] - 2026-10-24

- Dates follow Settings → General → Date format

## [1.0.0] - 2026-10-24

- Telegram bot for admins: GaiaCP's events (new orders, payments, tickets, servers down) as messages in a chat or group,
  and, when Commands is on, answers to /owed (who owes, overdue payment notices), /today, /tickets and /servers from
  that chat only. Settings → Telegram for the bot token (encrypted), Find chat ID and Send a test message
